# Spamrito v3.0
Spamrito e um SPAM de alta qualidade, utilizando API de serviços grandes como **Uber**, **99**, **Aiqfome**, **RecargaMulti**, **Vivo** e **Claro**.

## Requisitos
* NodeJS Instalado

## Instalação
* ```apt update && apt upgrade```
* ```apt install git -y```
* ```git clone https://github.com/KiritoOfficial/spamrito```
* ```cd spamrito```
* ```chmod +x *```
* ```bash install.sh```

## Exemplo de uso
Start: ```node spam.js```

![banner](https://user-images.githubusercontent.com/43851118/97900674-fe666780-1d08-11eb-9574-1c32777203d6.jpg)

## Contato
* [Telegram](https://t.me/KiritoOfficial)
* [Youtube](https://youtube.com/c/KiritoOfficial)
* [GitHub](https://github.com/KiritoOfficial)

## License

Copyright 2020 [KiritoOfficial](https://t.me/KiritoOfficial)
