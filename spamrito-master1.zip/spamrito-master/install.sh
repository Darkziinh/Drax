apt install nodejs -y
npm i colors
npm i crypto
npm i request
npm i readline-sync
npm i cli-progress
